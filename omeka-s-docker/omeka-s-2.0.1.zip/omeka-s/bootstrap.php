<?php
define('OMEKA_PATH', __DIR__);
chdir(OMEKA_PATH);
date_default_timezone_set('UTC');

require 'vendor/autoload.php';
