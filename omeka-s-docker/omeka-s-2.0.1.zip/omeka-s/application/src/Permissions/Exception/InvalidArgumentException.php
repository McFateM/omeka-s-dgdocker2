<?php
namespace Omeka\Permissions\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
