<?php
namespace Omeka\Service\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
