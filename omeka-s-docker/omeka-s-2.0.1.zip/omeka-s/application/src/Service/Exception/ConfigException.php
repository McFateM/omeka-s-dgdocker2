<?php
namespace Omeka\Service\Exception;

class ConfigException extends InvalidArgumentException
{
}
