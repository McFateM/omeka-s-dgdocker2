<?php
namespace OmekaTest\Db\Migration;

class MockInvalidMigration
{
}
