<?php
namespace OmekaTest\Job;

class Job extends \Omeka\Job\AbstractJob
{
    public function perform()
    {
    }
}
