<?php
namespace Omeka\File\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
