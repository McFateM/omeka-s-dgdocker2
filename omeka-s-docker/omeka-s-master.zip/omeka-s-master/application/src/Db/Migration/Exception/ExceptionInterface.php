<?php
namespace Omeka\Db\Migration\Exception;

interface ExceptionInterface
{
}
