<?php
namespace Omeka\Module\Exception;

class ModuleNotInDatabaseException extends \RuntimeException implements ExceptionInterface
{
}
